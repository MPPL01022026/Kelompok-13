import React from 'react';
import { Star, Sparkles, ArrowUpRight } from 'lucide-react';
import { SHOWCASE_PRODUCTS } from '../data/dashboardData';
import ProductItem3D from './3d/ProductItem3D';

export default function ProductShowcase() {
  return (
    <section className="luxury-showcase-section">
      <div className="section-header-editorial">
        <div>
          <span className="editorial-pill font-ui">
            <Sparkles size={12} className="gold-icon" /> Koleksi Kuliner Warisan
          </span>
          <h3 className="editorial-heading font-editorial">Showcase Lima Produk Unggulan</h3>
          <p className="editorial-subheading font-ui">
            Sajian gorengan dan jajanan tradisional berbahan baku organik, diolah segar setiap hari oleh Bu Pita.
          </p>
        </div>
        <span className="editorial-counter-badge font-ui">
          5 Menu Unggulan • 100% Homemade
        </span>
      </div>

      <div className="luxury-products-grid">
        {SHOWCASE_PRODUCTS.map((prod) => (
          <div key={prod.id} className="luxury-product-card">
            {/* 3D Visual Kuliner Nyata */}
            <div className="product-visual-stage">
              <ProductItem3D shapeType={prod.shapeType} />
              <span className="product-tag-pill font-ui">{prod.tag}</span>
            </div>

            <div className="product-card-body">
              <div className="product-title-row">
                <h4 className="product-name font-editorial">{prod.name}</h4>
                <div className="product-rating-box font-ui">
                  <Star size={12} className="star-gold-fill" />
                  <span>{prod.rating}</span>
                </div>
              </div>
              <span className="product-sub font-ui">{prod.subtitle}</span>
              <p className="product-narrative font-ui">{prod.description}</p>
            </div>

            <div className="product-stats-strip font-ui">
              <div className="strip-col">
                <span className="strip-lbl">Stok Etalase</span>
                <span className="strip-val">{prod.stock} pcs</span>
              </div>
              <div className="strip-sep"></div>
              <div className="strip-col">
                <span className="strip-lbl">Terjual Hari Ini</span>
                <span className="strip-val text-olive-bold">{prod.soldToday} pcs</span>
              </div>
            </div>

            <div className="product-card-footer font-ui">
              <div className="price-stack">
                <span className="price-caption">Harga Satuan</span>
                <strong className="price-figure">
                  Rp {prod.price.toLocaleString('id-ID')}
                </strong>
              </div>
              <span className="fresh-status-indicator">Freshly Fried</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
