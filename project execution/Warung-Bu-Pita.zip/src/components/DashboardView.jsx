import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Calendar,
  Clock,
  Award,
  ShieldCheck,
  Dot,
} from 'lucide-react';
import HeroSnackCanvas from './3d/HeroSnackCanvas';
import Production3DCard from './3d/Production3DCard';
import Stock3DCard from './3d/Stock3DCard';
import Sales3DCard from './3d/Sales3DCard';
import RawMaterials3DCard from './3d/RawMaterials3DCard';
import StatDetailModal from './StatDetailModal';
import TrendChart from './TrendChart';
import ProductShowcase from './ProductShowcase';
import RawMaterialsSummary from './RawMaterialsSummary';
import RecentActivities from './RecentActivities';
import { DASHBOARD_STATS } from '../data/dashboardData';

export default function DashboardView({ onNavigateToDigitalTwin }) {
  const [selectedStatForModal, setSelectedStatForModal] = useState(null);

  return (
    <div className="luxury-dashboard-view">
      {/* 1. Header Personal dengan Sapaan "Good day, Bu Pita" */}
      <header className="dashboard-editorial-header">
        <div className="editorial-greeting-col">
          <div className="editorial-pill font-ui">
            <Sparkles size={11} className="gold-icon" /> Alur Dua
          </div>
          <h2 className="greeting-main-title font-editorial">
            Good day, <span className="greeting-accent">Bu Pita</span>
          </h2>
          <p className="greeting-narrative font-ui">
            Dapur utama beroperasi dalam kapasitas optimal. Seluruh bahan baku organik siap olah
            dan lima sajian artisan telah dipersiapkan dengan standar cita rasa terbaik.
          </p>
        </div>

        <div className="editorial-header-meta font-ui">
          <div className="meta-pill-card">
            <span className="live-pulse"></span>
            <div className="meta-pill-text">
              <span className="meta-label">Status Etalase</span>
              <strong className="meta-val">Segar & Siap Saji</strong>
            </div>
          </div>

          <div className="meta-pill-card">
            <Calendar size={14} className="meta-icon" />
            <span className="meta-val">Sabtu, 31 Okt 2026</span>
            <span className="meta-sep">/</span>
            <Clock size={14} className="meta-icon" />
            <span className="meta-val">Shift Sore</span>
          </div>
        </div>
      </header>

      {/* 2. Hero Section Besar dengan Visual 3D Makanan Khas */}
      <section className="luxury-hero-panel">
        <div className="hero-editorial-copy">
          <div className="hero-kicker-pill font-ui">
            <Award size={13} className="gold-icon" /> Luxury Green × Modern Artisan Culinary
          </div>
          <h1 className="hero-headline font-editorial">
            Kehangatan Resep Warisan, Presisi Pengelolaan Modern.
          </h1>
          <p className="hero-lead font-ui">
            Pemantauan terpadu untuk lima sajian kuliner khas: <strong>Risol Sayur</strong>, <strong>Lumpia</strong>,{' '}
            <strong>Bakso Goreng</strong>, <strong>Tahu Isi</strong>, dan <strong>Pisang Coklat</strong>. Seluruh proses
            menjunjung integritas bahan organik, teknik penggorengan tradisional, dan pengawasan stok presisi.
          </p>

          <div className="hero-cta-group font-ui">
            <button
              type="button"
              className="btn-luxury-primary"
              onClick={onNavigateToDigitalTwin}
            >
              <span>Buka Menu Digital Twin</span>
              <ArrowRight size={16} />
            </button>
            <div className="hero-micro-stat">
              <span className="micro-number font-editorial">555</span>
              <span className="micro-caption font-ui">Total Stok Etalase Siap Saji</span>
            </div>
          </div>
        </div>

        {/* Visual 3D Kuliner Piring Artisan */}
        <div className="hero-3d-stage">
          <HeroSnackCanvas />
        </div>
      </section>

      {/* 3. Empat Statistik Bisnis dengan Visualisasi 3D Interaktif */}
      <section className="luxury-stats-section">
        <div className="section-header-editorial">
          <div>
            <span className="editorial-pill font-ui">
              <Sparkles size={11} className="gold-icon" /> Visualisasi 3D Real-time
            </span>
            <h3 className="editorial-heading font-editorial">Kondisi Bisnis & Operasional Kunci</h3>
            <p className="editorial-subheading font-ui">
              Pusat kendali empat indikator utama. Hover untuk informasi, drag untuk memutar 3D, atau klik untuk rincian data.
            </p>
          </div>
        </div>

        <div className="luxury-3d-stats-grid">
          {/* 1. Produksi Hari Ini: 3D Extruded Bar Chart */}
          <Production3DCard
            stats={DASHBOARD_STATS.production}
            onCardClick={setSelectedStatForModal}
          />

          {/* 2. Stok Produk: Susunan Objek 3D Produk Kuliner */}
          <Stock3DCard
            stats={DASHBOARD_STATS.stock}
            onCardClick={setSelectedStatForModal}
          />

          {/* 3. Penjualan Hari Ini: 3D Financial Bar Visualization */}
          <Sales3DCard
            stats={DASHBOARD_STATS.sales}
            onCardClick={setSelectedStatForModal}
          />

          {/* 4. Ketersediaan Bahan Baku: 3D Segmented Circular Gauge */}
          <RawMaterials3DCard
            stats={DASHBOARD_STATS.rawMaterials}
            onCardClick={setSelectedStatForModal}
          />
        </div>
      </section>

      {/* 4. Grafik Tren Produksi dan Penjualan */}
      <section className="luxury-trend-section">
        <TrendChart />
      </section>

      {/* 5. Showcase Lima Produk Unggulan */}
      <section className="luxury-showcase-wrapper">
        <ProductShowcase />
      </section>

      {/* 6. Asymmetrical Bottom Two Columns: Bahan Baku & Aktivitas Terbaru */}
      <section className="luxury-bottom-split">
        <div className="split-col-left">
          <RawMaterialsSummary />
        </div>
        <div className="split-col-right">
          <RecentActivities />
        </div>
      </section>

      {/* Modal Detail Statistik saat Kartu 3D Diklik */}
      <StatDetailModal
        statData={selectedStatForModal}
        onClose={() => setSelectedStatForModal(null)}
      />
    </div>
  );
}
