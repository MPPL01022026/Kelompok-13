import React from 'react';
import {
  Clock,
  Flame,
  ShoppingBag,
  CheckCircle2,
  Truck,
  Sparkles,
} from 'lucide-react';
import { RECENT_OPERATIONAL_ACTIVITIES } from '../data/dashboardData';

const iconMap = {
  Flame: Flame,
  ShoppingBag: ShoppingBag,
  CheckCircle2: CheckCircle2,
  Truck: Truck,
  Sparkles: Sparkles,
};

export default function RecentActivities() {
  return (
    <div className="luxury-activities-card">
      <div className="activities-card-header">
        <div>
          <span className="editorial-pill font-ui">
            <Clock size={12} className="gold-icon" /> Jurnal Operasional
          </span>
          <h3 className="activities-title font-editorial">Aktivitas Operasional Terbaru</h3>
          <p className="activities-subtitle font-ui">
            Catatan berkala proses penggorengan, transaksi kasir, dan penerimaan bahan hari ini.
          </p>
        </div>
        <span className="live-feed-badge font-ui">
          <span className="live-pulse"></span> Real-time
        </span>
      </div>

      <div className="activities-timeline font-ui">
        {RECENT_OPERATIONAL_ACTIVITIES.map((act, index) => {
          const IconComponent = iconMap[act.iconName] || Sparkles;
          return (
            <div key={act.id} className="timeline-entry">
              <div className="timeline-pillar">
                <div className="timeline-icon-wrap">
                  <IconComponent size={14} className="timeline-icon-svg" />
                </div>
                {index !== RECENT_OPERATIONAL_ACTIVITIES.length - 1 && (
                  <div className="timeline-stem"></div>
                )}
              </div>

              <div className="timeline-body">
                <div className="timeline-header-row">
                  <span className="entry-title">{act.title}</span>
                  <div className="entry-meta">
                    <span className="entry-badge">{act.badge}</span>
                    <span className="entry-time">{act.time}</span>
                  </div>
                </div>
                <p className="entry-desc">{act.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
