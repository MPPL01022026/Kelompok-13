import React from 'react';
import {
  LayoutDashboard,
  GitCompare,
  UtensilsCrossed,
  Package,
  ShoppingBag,
  FileBarChart,
  Settings,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Dot,
} from 'lucide-react';

export default function Sidebar({ activeTab, onSelectMenu, isMobileOpen, onCloseMobile }) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: 'Utama' },
    { id: 'digital-twin', label: 'Digital Twin', icon: GitCompare, badge: 'Stok' },
    { id: 'produksi', label: 'Produksi', icon: UtensilsCrossed, badge: null },
    { id: 'inventori', label: 'Inventori', icon: Package, badge: null },
    { id: 'penjualan', label: 'Penjualan', icon: ShoppingBag, badge: 'Kasir' },
    { id: 'laporan', label: 'Laporan', icon: FileBarChart, badge: null },
    { id: 'pengaturan', label: 'Pengaturan', icon: Settings, badge: null },
  ];

  return (
    <>
      {isMobileOpen && (
        <div className="luxury-sidebar-backdrop" onClick={onCloseMobile} />
      )}

      <aside className={`luxury-sidebar ${isMobileOpen ? 'open' : ''}`}>
        {/* Brand Header */}
        <div className="sidebar-brand-block">
          <div className="brand-crest">
            <span className="brand-crest-letter">P</span>
            <div className="crest-ring"></div>
          </div>
          <div className="brand-title-wrap">
            <h1 className="brand-name font-editorial">Warung Bu Pita</h1>
            <span className="brand-subtitle font-ui">Artisan Culinary Management</span>
          </div>
        </div>

        {/* Operational Status Pill */}
        <div className="sidebar-status-card">
          <div className="status-live-dot"></div>
          <div className="status-info">
            <span className="status-title font-ui">Dapur Utama Aktif</span>
            <span className="status-schedule font-ui">07:00 – 21:00 WIB</span>
          </div>
        </div>

        {/* Navigation Menus */}
        <nav className="sidebar-nav-container">
          <span className="nav-group-heading font-ui">NAVIGASI SISTEM</span>
          <ul className="nav-menu-list">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <li key={item.id} className="nav-menu-item">
                  <button
                    type="button"
                    className={`nav-menu-button font-ui ${isActive ? 'active' : ''}`}
                    onClick={() => {
                      onSelectMenu(item.id);
                      if (onCloseMobile) onCloseMobile();
                    }}
                  >
                    <Icon size={18} strokeWidth={1.8} className="nav-menu-icon" />
                    <span className="nav-menu-label">{item.label}</span>
                    {item.badge && (
                      <span className="nav-menu-badge">{item.badge}</span>
                    )}
                    {isActive && <ChevronRight size={14} className="nav-menu-arrow" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Profile Bu Pita (Refined Luxury Footer) */}
        <div className="sidebar-profile-box">
          <div className="profile-crest-avatar">
            <span className="profile-initials">BP</span>
          </div>
          <div className="profile-meta">
            <span className="profile-person-name font-editorial">Ibu Pita</span>
            <span className="profile-person-role font-ui">Owner & Head Chef</span>
            <span className="profile-seal-tag font-ui">
              <Sparkles size={10} className="gold-icon" /> Est. 2024
            </span>
          </div>
        </div>
      </aside>
    </>
  );
}
