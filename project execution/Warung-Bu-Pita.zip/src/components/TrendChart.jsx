import React, { useState } from 'react';
import { TrendingUp, Sparkles } from 'lucide-react';
import { HOURLY_TRENDS } from '../data/dashboardData';

export default function TrendChart() {
  const [activeFilter, setActiveFilter] = useState('today');
  const [hoveredPoint, setHoveredPoint] = useState(null);

  const width = 640;
  const height = 220;
  const paddingX = 40;
  const paddingY = 30;
  const maxVal = 160;

  const pointsProduksi = HOURLY_TRENDS.map((d, i) => {
    const x = paddingX + (i / (HOURLY_TRENDS.length - 1)) * (width - paddingX * 2);
    const y = height - paddingY - (d.produksi / maxVal) * (height - paddingY * 2);
    return { ...d, x, y };
  });

  const pointsPenjualan = HOURLY_TRENDS.map((d, i) => {
    const x = paddingX + (i / (HOURLY_TRENDS.length - 1)) * (width - paddingX * 2);
    const y = height - paddingY - (d.penjualan / maxVal) * (height - paddingY * 2);
    return { ...d, x, y };
  });

  const createSmoothPath = (pts) => {
    if (pts.length === 0) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i];
      const p1 = pts[i + 1];
      const cx = (p0.x + p1.x) / 2;
      d += ` C ${cx} ${p0.y}, ${cx} ${p1.y}, ${p1.x} ${p1.y}`;
    }
    return d;
  };

  const pathProduksi = createSmoothPath(pointsProduksi);
  const pathPenjualan = createSmoothPath(pointsPenjualan);

  const areaProduksi = `${pathProduksi} L ${pointsProduksi[pointsProduksi.length - 1].x} ${height - paddingY} L ${pointsProduksi[0].x} ${height - paddingY} Z`;
  const areaPenjualan = `${pathPenjualan} L ${pointsPenjualan[pointsPenjualan.length - 1].x} ${height - paddingY} L ${pointsPenjualan[0].x} ${height - paddingY} Z`;

  return (
    <div className="luxury-trend-card">
      <div className="trend-header-row">
        <div>
          <span className="editorial-pill font-ui">
            <TrendingUp size={12} className="gold-icon" /> Analitik Operasional
          </span>
          <h3 className="trend-title font-editorial">Grafik Tren Produksi & Penjualan</h3>
          <p className="trend-subtitle font-ui">
            Korelasi kapasitas penggorengan dapur terhadap kecepatan serapan etalase per interval 2 jam.
          </p>
        </div>

        <div className="trend-controls-row font-ui">
          <div className="trend-legend-group">
            <span className="legend-marker">
              <span className="marker-dot bg-forest"></span> Produksi (pcs)
            </span>
            <span className="legend-marker">
              <span className="marker-dot bg-gold"></span> Penjualan (pcs)
            </span>
          </div>

          <div className="trend-period-switch">
            <button
              type="button"
              className={`period-btn ${activeFilter === 'today' ? 'active' : ''}`}
              onClick={() => setActiveFilter('today')}
            >
              Hari Ini
            </button>
            <button
              type="button"
              className={`period-btn ${activeFilter === 'yesterday' ? 'active' : ''}`}
              onClick={() => setActiveFilter('yesterday')}
            >
              Kemarin
            </button>
          </div>
        </div>
      </div>

      <div className="trend-svg-stage">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="trend-chart-svg"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="gradForest" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#193C2E" stopOpacity="0.22" />
              <stop offset="100%" stopColor="#193C2E" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="gradGold" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#C5A66B" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#C5A66B" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines horizontal */}
          {[40, 80, 120, 160].map((v) => {
            const y = height - paddingY - (v / maxVal) * (height - paddingY * 2);
            return (
              <g key={v}>
                <line
                  x1={paddingX}
                  y1={y}
                  x2={width - paddingX}
                  y2={y}
                  stroke="#E4E5DA"
                  strokeDasharray="4 4"
                  strokeWidth="1"
                />
                <text
                  x={paddingX - 10}
                  y={y + 4}
                  textAnchor="end"
                  fontSize="10"
                  fill="#71836A"
                  fontFamily="Manrope, sans-serif"
                >
                  {v}
                </text>
              </g>
            );
          })}

          {/* Area Gradients */}
          <path d={areaProduksi} fill="url(#gradForest)" />
          <path d={areaPenjualan} fill="url(#gradGold)" />

          {/* Stroke Curves */}
          <path
            d={pathProduksi}
            fill="none"
            stroke="#193C2E"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          <path
            d={pathPenjualan}
            fill="none"
            stroke="#C5A66B"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* X Axis Time Labels & Interactive Points */}
          {pointsProduksi.map((pt, i) => {
            const ptJual = pointsPenjualan[i];
            const isHovered = hoveredPoint?.time === pt.time;

            return (
              <g key={pt.time}>
                {isHovered && (
                  <line
                    x1={pt.x}
                    y1={paddingY}
                    x2={pt.x}
                    y2={height - paddingY}
                    stroke="#C5A66B"
                    strokeWidth="1.5"
                    strokeDasharray="3 3"
                  />
                )}

                {/* Titik Produksi Forest Green */}
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r={isHovered ? 6 : 4}
                  fill="#FCFBF7"
                  stroke="#193C2E"
                  strokeWidth="2.5"
                  className="interactive-point"
                  onMouseEnter={() => setHoveredPoint(pt)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />

                {/* Titik Penjualan Warm Gold */}
                <circle
                  cx={ptJual.x}
                  cy={ptJual.y}
                  r={isHovered ? 6 : 4}
                  fill="#FCFBF7"
                  stroke="#C5A66B"
                  strokeWidth="2.5"
                  className="interactive-point"
                  onMouseEnter={() => setHoveredPoint(pt)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />

                {/* Label Jam */}
                <text
                  x={pt.x}
                  y={height - 10}
                  textAnchor="middle"
                  fontSize="11"
                  fill="#5E7265"
                  fontWeight="600"
                  fontFamily="Manrope, sans-serif"
                >
                  {pt.time}
                </text>
              </g>
            );
          })}
        </svg>

        {hoveredPoint && (
          <div
            className="chart-hover-box font-ui"
            style={{
              left: `${(hoveredPoint.x / width) * 100}%`,
              top: '18px',
            }}
          >
            <strong>Waktu: {hoveredPoint.time} WIB</strong>
            <div className="tooltip-line text-forest">
              <span>Produksi:</span> <strong>{hoveredPoint.produksi} pcs</strong>
            </div>
            <div className="tooltip-line text-gold">
              <span>Penjualan:</span> <strong>{hoveredPoint.penjualan} pcs</strong>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
