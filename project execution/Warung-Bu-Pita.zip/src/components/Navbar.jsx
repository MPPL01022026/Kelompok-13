import React from 'react';
import { Sparkles, LayoutDashboard, GitCompare, Store, CheckCircle2 } from 'lucide-react';
import { DEMO_METADATA } from '../data/initialProducts';

export default function Navbar({ activeTab, setActiveTab, lastCompliance }) {
  return (
    <header className="navbar-container">
      {/* Top micro banner for demo metadata */}
      <div className="navbar-top-banner">
        <div className="banner-content">
          <span className="demo-badge">
            <Sparkles size={13} className="sparkle-icon" /> {DEMO_METADATA.dataTag}
          </span>
          <span className="location-info">
            📍 {DEMO_METADATA.location} • {DEMO_METADATA.operatorName}
          </span>
        </div>
      </div>

      {/* Main navigation header */}
      <div className="navbar-main">
        <div className="brand-section">
          <div className="brand-logo-circle">
            <span className="brand-icon">🍵</span>
          </div>
          <div className="brand-text">
            <h1 className="brand-title font-serif">{DEMO_METADATA.storeName}</h1>
            <p className="brand-subtitle font-sans">
              <span>Cute Luxury</span> × <span>Artisan Culinary Twin</span>
            </p>
          </div>
        </div>

        {/* Menu Navigation Tabs (Alur Langkah 1: Operator memilih menu) */}
        <nav className="nav-tabs" aria-label="Navigasi Menu Utama">
          <button
            type="button"
            className={`nav-tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <LayoutDashboard size={18} />
            <span>Dashboard</span>
            {lastCompliance !== null && (
              <span className="nav-pill-badge" title="Tingkat Kesesuaian Terbaru">
                {lastCompliance.persentaseKesesuaian}%
              </span>
            )}
          </button>

          <button
            type="button"
            className={`nav-tab-btn ${activeTab === 'digital-twin' ? 'active' : ''}`}
            onClick={() => setActiveTab('digital-twin')}
          >
            <GitCompare size={18} />
            <span>Digital Twin</span>
            <span className="nav-badge-pill">Rekonsiliasi Stok</span>
          </button>
        </nav>
      </div>
    </header>
  );
}

