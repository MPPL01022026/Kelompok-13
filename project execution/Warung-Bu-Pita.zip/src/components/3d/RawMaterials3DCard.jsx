import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

// 3D Segmented Circular Gauge Luxury Green
function LuxurySegmentedGauge({ segments, onHoverSegment }) {
  const groupRef = useRef();

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.z += delta * 0.16;
    }
  });

  const totalSegments = segments.length;
  const radius = 1.05;
  const tube = 0.17;
  const arcPerSegment = (Math.PI * 2) / totalSegments;
  const gap = 0.08;

  return (
    <group position={[0, 0, 0]}>
      {/* Cincin Luar Berputar Luxury Green Segments */}
      <group ref={groupRef}>
        {segments.map((seg, i) => {
          const startAngle = i * arcPerSegment + gap / 2;
          const arcLength = arcPerSegment - gap;

          return (
            <mesh
              key={seg.name}
              rotation={[Math.PI / 2, 0, startAngle]}
              castShadow
              onPointerOver={(e) => {
                e.stopPropagation();
                onHoverSegment(seg);
              }}
              onPointerOut={(e) => {
                e.stopPropagation();
                onHoverSegment(null);
              }}
            >
              <torusGeometry args={[radius, tube, 24, 32, arcLength]} />
              <meshStandardMaterial
                color={seg.color}
                roughness={0.28}
                metalness={0.2}
              />
            </mesh>
          );
        })}
      </group>

      {/* Inti Pusat 3D (Soft Ivory Orb) */}
      <mesh position={[0, 0, 0]} castShadow>
        <sphereGeometry args={[0.55, 32, 32]} />
        <meshStandardMaterial
          color="#FAF9F4"
          roughness={0.2}
          metalness={0.05}
          clearcoat={0.3}
        />
      </mesh>

      {/* Ring Aksen Warm Gold Mengelilingi Inti */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.65, 0.035, 16, 48]} />
        <meshStandardMaterial color="#C5A66B" roughness={0.25} metalness={0.65} />
      </mesh>
    </group>
  );
}

export default function RawMaterials3DCard({ stats, onCardClick }) {
  const [hoveredSeg, setHoveredSeg] = useState(null);

  return (
    <div
      className="luxury-stat-card"
      onClick={() => onCardClick(stats)}
      role="button"
      tabIndex={0}
      title="Klik untuk membuka rincian stok bahan baku"
    >
      <div className="stat-card-header">
        <div>
          <span className="stat-category-tag font-ui">Gudang Bahan</span>
          <h4 className="stat-heading font-editorial">{stats.title}</h4>
        </div>
        <span className="stat-badge-achievement font-ui">
          {stats.statusLevel}
        </span>
      </div>

      <div className="stat-metric-primary">
        <span className="stat-metric-number font-ui">{stats.availabilityPct}%</span>
        <span className="stat-metric-unit font-ui">Tersedia</span>
        <span className="stat-metric-context font-ui">6 komoditas utama artisan</span>
      </div>

      <div className="stat-3d-viewport">
        <Canvas
          camera={{ position: [0, 0, 3.2], fov: 42 }}
          shadows
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={1.2} />
          <directionalLight position={[4, 5, 4]} intensity={1.6} castShadow />
          <pointLight position={[-3, -2, 2]} intensity={0.5} color="#C5A66B" />

          <LuxurySegmentedGauge
            segments={stats.segments}
            onHoverSegment={setHoveredSeg}
          />

          <OrbitControls
            enableZoom={false}
            enablePan={false}
            rotateSpeed={0.8}
          />
        </Canvas>

        {hoveredSeg ? (
          <div className="stat-tooltip-overlay font-ui">
            <strong>{hoveredSeg.name}</strong>
            <span>{hoveredSeg.stock} dari {hoveredSeg.max} ({hoveredSeg.pct}%)</span>
          </div>
        ) : (
          <div className="stat-drag-hint font-ui">
            Drag untuk memutar • Hover segmen bahan
          </div>
        )}
      </div>

      <div className="stat-card-footer">
        <span className="stat-status-indicator font-ui">
          <span className="status-dot-green"></span> {stats.statusNote}
        </span>
        <span className="stat-detail-link font-ui">Rincian →</span>
      </div>
    </div>
  );
}
