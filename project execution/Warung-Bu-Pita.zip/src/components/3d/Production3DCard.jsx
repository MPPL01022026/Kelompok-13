import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { RoundedBox, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

function ProductionBars({ batches, onHoverItem }) {
  const groupRef = useRef();

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.22;
    }
  });

  const barWidth = 0.44;
  const spacing = 0.65;
  const startX = -((batches.length - 1) * spacing) / 2;

  return (
    <group ref={groupRef} position={[0, -0.6, 0]}>
      {/* Alas Platform Keramik Ivory dengan Garis Forest Green */}
      <mesh position={[0, -0.06, 0]} receiveShadow>
        <cylinderGeometry args={[1.75, 1.85, 0.1, 32]} />
        <meshStandardMaterial color="#E8EAE0" roughness={0.5} />
      </mesh>
      <mesh position={[0, -0.01, 0]}>
        <cylinderGeometry args={[1.65, 1.65, 0.02, 32]} />
        <meshStandardMaterial color="#193C2E" roughness={0.3} />
      </mesh>

      {batches.map((batch, index) => {
        const height = (batch.value / 180) * 1.5 + 0.35;
        const xPos = startX + index * spacing;

        return (
          <group
            key={batch.id}
            position={[xPos, height / 2, 0]}
            onPointerOver={(e) => {
              e.stopPropagation();
              onHoverItem(batch);
            }}
            onPointerOut={(e) => {
              e.stopPropagation();
              onHoverItem(null);
            }}
          >
            <RoundedBox
              args={[barWidth, height, barWidth]}
              radius={0.06}
              smoothness={4}
              castShadow
            >
              <meshStandardMaterial
                color={batch.color}
                roughness={0.3}
                metalness={0.12}
              />
            </RoundedBox>

            {/* Aksen Top Cap Warm Gold */}
            <mesh position={[0, height / 2 + 0.02, 0]}>
              <cylinderGeometry args={[barWidth / 2.4, barWidth / 2.4, 0.035, 16]} />
              <meshStandardMaterial color="#C5A66B" roughness={0.2} metalness={0.6} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

export default function Production3DCard({ stats, onCardClick }) {
  const [hoveredBatch, setHoveredBatch] = useState(null);

  return (
    <div
      className="luxury-stat-card"
      onClick={() => onCardClick(stats)}
      role="button"
      tabIndex={0}
      title="Klik untuk membuka rincian produksi harian"
    >
      <div className="stat-card-header">
        <div>
          <span className="stat-category-tag font-ui">Dapur Produksi</span>
          <h4 className="stat-heading font-editorial">{stats.title}</h4>
        </div>
        <span className="stat-badge-achievement font-ui">
          {stats.achievementPct}% Target
        </span>
      </div>

      <div className="stat-metric-primary">
        <span className="stat-metric-number font-ui">{stats.total}</span>
        <span className="stat-metric-unit font-ui">{stats.unit}</span>
        <span className="stat-metric-context font-ui">Target: {stats.target} {stats.unit}</span>
      </div>

      <div className="stat-3d-viewport">
        <Canvas
          camera={{ position: [0, 2.0, 3.2], fov: 42 }}
          shadows
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={1.1} />
          <directionalLight position={[4, 6, 3]} intensity={1.5} castShadow />
          <pointLight position={[-3, 2, -2]} intensity={0.5} color="#C5A66B" />

          <ProductionBars
            batches={stats.batches}
            onHoverItem={setHoveredBatch}
          />

          <OrbitControls
            enableZoom={false}
            enablePan={false}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 2.2}
          />
        </Canvas>

        {hoveredBatch ? (
          <div className="stat-tooltip-overlay font-ui">
            <strong>{hoveredBatch.label} ({hoveredBatch.time})</strong>
            <span>{hoveredBatch.item}: {hoveredBatch.value} pcs</span>
          </div>
        ) : (
          <div className="stat-drag-hint font-ui">
            Drag untuk memutar • Hover batang 3D
          </div>
        )}
      </div>

      <div className="stat-card-footer">
        <span className="stat-status-indicator font-ui">
          <span className="status-dot-green"></span> {stats.statusNote}
        </span>
        <span className="stat-detail-link font-ui">Rincian →</span>
      </div>
    </div>
  );
}
