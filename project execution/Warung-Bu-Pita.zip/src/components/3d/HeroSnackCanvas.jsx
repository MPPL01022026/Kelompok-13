import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, OrbitControls, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

// Komponen 3D Piring Artisan & Susunan Camilan Tradisional Luxury Green
function LuxuryArtisanPlatter() {
  const groupRef = useRef();

  useFrame((_, delta) => {
    if (groupRef.current) {
      // Rotasi perlahan dan elegan
      groupRef.current.rotation.y += delta * 0.28;
    }
  });

  return (
    <group ref={groupRef} position={[0, -0.22, 0]}>
      {/* Piring Keramik Soft Ivory Glaze */}
      <mesh position={[0, -0.3, 0]} receiveShadow>
        <cylinderGeometry args={[2.8, 2.3, 0.22, 64]} />
        <meshStandardMaterial
          color="#FAF9F4"
          roughness={0.2}
          metalness={0.05}
          clearcoat={0.35}
          clearcoatRoughness={0.15}
        />
      </mesh>

      {/* Bibir Piring Aksen Warm Gold Luxury */}
      <mesh position={[0, -0.19, 0]}>
        <torusGeometry args={[2.7, 0.065, 16, 64]} />
        <meshStandardMaterial
          color="#C5A66B"
          roughness={0.25}
          metalness={0.65}
        />
      </mesh>

      {/* 1. Risol Sayur (Silinder Keemasan Renyah dengan Tepung Panir) */}
      <group position={[-0.8, 0.05, 0.5]} rotation={[0, 0.4, 0]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.3, 0.3, 1.25, 32]} />
          <meshStandardMaterial color="#D9B772" roughness={0.45} />
        </mesh>
        <mesh position={[0, 0.02, 0]}>
          <cylinderGeometry args={[0.31, 0.31, 0.95, 20]} />
          <meshStandardMaterial color="#C5A66B" roughness={0.6} />
        </mesh>
      </group>

      {/* 2. Lumpia (Roll Ramping Keemasan) */}
      <group position={[0.7, 0.05, 0.55]} rotation={[0, -0.5, 0]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.26, 0.26, 1.35, 32]} />
          <meshStandardMaterial color="#DEBF7D" roughness={0.35} />
        </mesh>
        <mesh position={[0, 0.1, 0.02]} rotation={[0.15, 0, 0]}>
          <boxGeometry args={[0.08, 0.7, 0.28]} />
          <meshStandardMaterial color="#A88B4E" roughness={0.5} />
        </mesh>
      </group>

      {/* 3. Bakso Goreng (Bulat Mekar Renyah) */}
      <group position={[0, 0.22, -0.4]}>
        <mesh castShadow>
          <sphereGeometry args={[0.48, 32, 32]} />
          <meshStandardMaterial color="#B88A4A" roughness={0.55} />
        </mesh>
        <mesh position={[0.1, 0.15, 0.08]}>
          <sphereGeometry args={[0.22, 16, 16]} />
          <meshStandardMaterial color="#9C7238" roughness={0.65} />
        </mesh>
      </group>

      {/* 4. Tahu Isi (Balok Coklat Keemasan) */}
      <group position={[-0.85, 0.05, -0.55]} rotation={[0.1, 0.75, -0.1]}>
        <RoundedBox args={[0.65, 0.55, 0.7]} radius={0.08} smoothness={4} castShadow>
          <meshStandardMaterial color="#CBA458" roughness={0.5} />
        </RoundedBox>
      </group>

      {/* 5. Pisang Coklat (Silinder Manis dengan Aksen Coklat Gelap) */}
      <group position={[0.85, 0.08, -0.45]} rotation={[-0.1, -0.65, 0.1]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.28, 0.28, 1.15, 32]} />
          <meshStandardMaterial color="#C29B52" roughness={0.4} />
        </mesh>
        <mesh position={[0, 0.16, 0.08]}>
          <sphereGeometry args={[0.2, 16, 16]} />
          <meshStandardMaterial color="#193C2E" roughness={0.2} metalness={0.15} />
        </mesh>
      </group>

      {/* Garnish Daun Sage & Kemangi Hijau Mewah */}
      <mesh position={[0, 0.16, 0.32]} rotation={[-0.4, 0.2, 0.3]}>
        <coneGeometry args={[0.2, 0.45, 6]} />
        <meshStandardMaterial color="#315640" roughness={0.35} />
      </mesh>
      <mesh position={[-0.2, 0.06, 0.7]} rotation={[0.5, 0.8, 0]}>
        <cylinderGeometry args={[0.05, 0.02, 0.38, 12]} />
        <meshStandardMaterial color="#71836A" roughness={0.3} />
      </mesh>
    </group>
  );
}

export default function HeroSnackCanvas() {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="hero-3d-canvas-wrapper"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title="Interactive 3D • Drag untuk memutar piring sajian artisan Warung Bu Pita"
    >
      <Canvas
        camera={{ position: [0, 3.2, 4.3], fov: 42 }}
        shadows
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={1.0} />
        <directionalLight
          position={[5, 8, 4]}
          intensity={1.8}
          castShadow
          shadow-mapSize={[1024, 1024]}
          color="#FFFDF5"
        />
        <pointLight position={[-4, 3, -2]} intensity={0.6} color="#F5F4EC" />
        <pointLight position={[0, 2, 3]} intensity={0.5} color="#C5A66B" />

        <Float speed={1.6} rotationIntensity={0.18} floatIntensity={0.25}>
          <LuxuryArtisanPlatter />
        </Float>

        <OrbitControls
          enableZoom={false}
          enablePan={false}
          minPolarAngle={Math.PI / 4.2}
          maxPolarAngle={Math.PI / 2.3}
          rotateSpeed={0.8}
        />
      </Canvas>

      <div className="hero-3d-tag font-ui">
        <span className="dot-live"></span> 3D Artisan Platter • Drag to Rotate
      </div>
    </div>
  );
}
