import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { RoundedBox, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

function LuxurySnackStack({ products, onHoverProduct }) {
  const groupRef = useRef();

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.2;
    }
  });

  return (
    <group ref={groupRef} position={[0, -0.45, 0]}>
      {/* Wadah Tiered Display Forest Green & Warm Gold */}
      <mesh position={[0, -0.05, 0]} receiveShadow>
        <cylinderGeometry args={[1.7, 1.8, 0.1, 32]} />
        <meshStandardMaterial color="#193C2E" roughness={0.4} />
      </mesh>
      <mesh position={[0, -0.005, 0]}>
        <cylinderGeometry args={[1.62, 1.62, 0.02, 32]} />
        <meshStandardMaterial color="#C5A66B" roughness={0.3} metalness={0.5} />
      </mesh>
      <mesh position={[0, 0.26, 0]}>
        <cylinderGeometry args={[1.0, 1.1, 0.08, 32]} />
        <meshStandardMaterial color="#FAF9F4" roughness={0.3} />
      </mesh>

      {/* 1. Risol Sayur (Silinder Warm Gold) */}
      <group
        position={[-0.7, 0.2, 0.5]}
        rotation={[0, 0.4, 0]}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHoverProduct(products[0]);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onHoverProduct(null);
        }}
      >
        <mesh castShadow>
          <cylinderGeometry args={[0.2, 0.2, 0.7, 24]} />
          <meshStandardMaterial color={products[0]?.color || '#C5A66B'} roughness={0.4} />
        </mesh>
      </group>

      {/* 2. Lumpia (Silinder Sage Green) */}
      <group
        position={[0.7, 0.2, 0.4]}
        rotation={[0, -0.5, 0]}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHoverProduct(products[1]);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onHoverProduct(null);
        }}
      >
        <mesh castShadow>
          <cylinderGeometry args={[0.18, 0.18, 0.8, 24]} />
          <meshStandardMaterial color={products[1]?.color || '#9BAF9B'} roughness={0.4} />
        </mesh>
      </group>

      {/* 3. Bakso Goreng (Bola Mekar Olive Green) */}
      <group
        position={[0, 0.55, 0]}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHoverProduct(products[2]);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onHoverProduct(null);
        }}
      >
        <mesh castShadow>
          <sphereGeometry args={[0.32, 24, 24]} />
          <meshStandardMaterial color={products[2]?.color || '#315640'} roughness={0.5} />
        </mesh>
      </group>

      {/* 4. Tahu Isi (Balok Moss Green) */}
      <group
        position={[-0.6, 0.18, -0.6]}
        rotation={[0, 0.8, 0]}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHoverProduct(products[3]);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onHoverProduct(null);
        }}
      >
        <RoundedBox args={[0.42, 0.35, 0.42]} radius={0.05} smoothness={4} castShadow>
          <meshStandardMaterial color={products[3]?.color || '#71836A'} roughness={0.5} />
        </RoundedBox>
      </group>

      {/* 5. Pisang Coklat (Silinder Forest Green) */}
      <group
        position={[0.6, 0.2, -0.5]}
        rotation={[0, -0.7, 0]}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHoverProduct(products[4]);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onHoverProduct(null);
        }}
      >
        <mesh castShadow>
          <cylinderGeometry args={[0.2, 0.2, 0.75, 24]} />
          <meshStandardMaterial color={products[4]?.color || '#193C2E'} roughness={0.3} metalness={0.2} />
        </mesh>
      </group>
    </group>
  );
}

export default function Stock3DCard({ stats, onCardClick }) {
  const [hoveredProduct, setHoveredProduct] = useState(null);

  return (
    <div
      className="luxury-stat-card"
      onClick={() => onCardClick(stats)}
      role="button"
      tabIndex={0}
      title="Klik untuk membuka rincian stok etalase"
    >
      <div className="stat-card-header">
        <div>
          <span className="stat-category-tag font-ui">Inventori Display</span>
          <h4 className="stat-heading font-editorial">{stats.title}</h4>
        </div>
        <span className="stat-badge-achievement font-ui">
          5 Item Menu
        </span>
      </div>

      <div className="stat-metric-primary">
        <span className="stat-metric-number font-ui">{stats.total}</span>
        <span className="stat-metric-unit font-ui">{stats.unit}</span>
        <span className="stat-metric-context font-ui">Tersedia segar di etalase</span>
      </div>

      <div className="stat-3d-viewport">
        <Canvas
          camera={{ position: [0, 2.2, 3.2], fov: 42 }}
          shadows
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={1.1} />
          <directionalLight position={[4, 7, 3]} intensity={1.5} castShadow />
          <pointLight position={[-3, 2, -2]} intensity={0.5} color="#C5A66B" />

          <LuxurySnackStack
            products={stats.products}
            onHoverProduct={setHoveredProduct}
          />

          <OrbitControls
            enableZoom={false}
            enablePan={false}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 2.2}
          />
        </Canvas>

        {hoveredProduct ? (
          <div className="stat-tooltip-overlay font-ui">
            <strong>{hoveredProduct.name}</strong>
            <span>{hoveredProduct.qty} {hoveredProduct.unit} • {hoveredProduct.category}</span>
          </div>
        ) : (
          <div className="stat-drag-hint font-ui">
            Drag untuk memutar • Hover objek kuliner
          </div>
        )}
      </div>

      <div className="stat-card-footer">
        <span className="stat-status-indicator font-ui">
          <span className="status-dot-green"></span> {stats.statusNote}
        </span>
        <span className="stat-detail-link font-ui">Rincian →</span>
      </div>
    </div>
  );
}
