import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

function SnackMesh({ shapeType }) {
  const meshRef = useRef();

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.45;
    }
  });

  return (
    <group ref={meshRef}>
      {/* Plinth Dudukan Keramik Mini */}
      <mesh position={[0, -0.65, 0]} receiveShadow>
        <cylinderGeometry args={[1.05, 1.15, 0.08, 32]} />
        <meshStandardMaterial color="#FAF9F4" roughness={0.25} />
      </mesh>
      <mesh position={[0, -0.6, 0]}>
        <torusGeometry args={[1.02, 0.025, 16, 48]} />
        <meshStandardMaterial color="#C5A66B" roughness={0.3} metalness={0.6} />
      </mesh>

      {shapeType === 'risol' && (
        <group position={[0, -0.05, 0]} rotation={[0.2, 0, 0.1]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.38, 0.38, 1.3, 32]} />
            <meshStandardMaterial color="#D9B772" roughness={0.45} />
          </mesh>
          <mesh position={[0, 0, 0]}>
            <cylinderGeometry args={[0.395, 0.395, 1.0, 20]} />
            <meshStandardMaterial color="#C5A66B" roughness={0.65} />
          </mesh>
        </group>
      )}

      {shapeType === 'lumpia' && (
        <group position={[0, -0.05, 0]} rotation={[0.2, 0.3, -0.15]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.32, 0.32, 1.45, 32]} />
            <meshStandardMaterial color="#DEBF7D" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0.1, 0.02]} rotation={[0.1, 0, 0]}>
            <boxGeometry args={[0.1, 0.75, 0.34]} />
            <meshStandardMaterial color="#A88B4E" roughness={0.5} />
          </mesh>
        </group>
      )}

      {shapeType === 'bakso' && (
        <group position={[0, 0.05, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.62, 32, 32]} />
            <meshStandardMaterial color="#B88A4A" roughness={0.55} />
          </mesh>
          <mesh position={[0.12, 0.18, 0.1]}>
            <sphereGeometry args={[0.26, 16, 16]} />
            <meshStandardMaterial color="#9C7238" roughness={0.65} />
          </mesh>
        </group>
      )}

      {shapeType === 'tahu' && (
        <group position={[0, 0, 0]} rotation={[0.15, 0.4, 0]}>
          <RoundedBox args={[0.85, 0.75, 0.85]} radius={0.1} smoothness={4} castShadow>
            <meshStandardMaterial color="#CBA458" roughness={0.5} />
          </RoundedBox>
        </group>
      )}

      {shapeType === 'piscok' && (
        <group position={[0, -0.05, 0]} rotation={[-0.15, -0.3, 0.1]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.36, 0.36, 1.35, 32]} />
            <meshStandardMaterial color="#C29B52" roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.2, 0.1]}>
            <sphereGeometry args={[0.26, 16, 16]} />
            <meshStandardMaterial color="#193C2E" roughness={0.2} metalness={0.15} />
          </mesh>
        </group>
      )}
    </group>
  );
}

export default function ProductItem3D({ shapeType }) {
  return (
    <div className="product-3d-canvas-wrap">
      <Canvas
        camera={{ position: [0, 1.4, 2.7], fov: 38 }}
        shadows
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={1.1} />
        <directionalLight
          position={[3, 5, 3]}
          intensity={1.7}
          castShadow
          color="#FFFDF5"
        />
        <pointLight position={[-2, 1, -1]} intensity={0.4} color="#C5A66B" />

        <Float speed={1.5} rotationIntensity={0.15} floatIntensity={0.2}>
          <SnackMesh shapeType={shapeType} />
        </Float>
      </Canvas>
    </div>
  );
}

