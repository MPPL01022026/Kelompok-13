import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

function LuxuryFinancialPillars({ pillars, onHoverPillar }) {
  const groupRef = useRef();

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.22;
    }
  });

  const radius = 0.95;

  return (
    <group ref={groupRef} position={[0, -0.65, 0]}>
      {/* Dasar Platform Kasir Deep Forest Green dengan Ring Warm Gold */}
      <mesh position={[0, -0.05, 0]} receiveShadow>
        <cylinderGeometry args={[1.7, 1.8, 0.1, 32]} />
        <meshStandardMaterial color="#193C2E" roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.01, 0]}>
        <cylinderGeometry args={[1.52, 1.52, 0.03, 32]} />
        <meshStandardMaterial color="#C5A66B" roughness={0.25} metalness={0.65} />
      </mesh>

      {pillars.map((pillar, index) => {
        const angle = (index / pillars.length) * Math.PI * 2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const height = pillar.height;

        return (
          <group
            key={pillar.time}
            position={[x, height / 2, z]}
            onPointerOver={(e) => {
              e.stopPropagation();
              onHoverPillar(pillar);
            }}
            onPointerOut={(e) => {
              e.stopPropagation();
              onHoverPillar(null);
            }}
          >
            {/* Pilar Silinder Keuangan 3D Forest & Olive Greens */}
            <mesh castShadow receiveShadow>
              <cylinderGeometry args={[0.22, 0.22, height, 24]} />
              <meshStandardMaterial
                color={pillar.color}
                roughness={0.25}
                metalness={0.35}
              />
            </mesh>

            {/* Aksen Koin Warm Gold di Puncak Pilar */}
            <mesh position={[0, height / 2 + 0.03, 0]}>
              <cylinderGeometry args={[0.24, 0.24, 0.05, 24]} />
              <meshStandardMaterial color="#C5A66B" roughness={0.2} metalness={0.7} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

export default function Sales3DCard({ stats, onCardClick }) {
  const [hoveredPillar, setHoveredPillar] = useState(null);

  return (
    <div
      className="luxury-stat-card"
      onClick={() => onCardClick(stats)}
      role="button"
      tabIndex={0}
      title="Klik untuk membuka rincian penjualan kasir"
    >
      <div className="stat-card-header">
        <div>
          <span className="stat-category-tag font-ui">Penjualan Kasir</span>
          <h4 className="stat-heading font-editorial">{stats.title}</h4>
        </div>
        <span className="stat-badge-achievement font-ui">
          {stats.achievementPct}% Target
        </span>
      </div>

      <div className="stat-metric-primary">
        <span className="stat-metric-number font-ui">
          Rp {(stats.revenue / 1000).toLocaleString('id-ID')}k
        </span>
        <span className="stat-metric-unit font-ui">({stats.transactions} tx)</span>
        <span className="stat-metric-context font-ui">
          Target: Rp {(stats.targetRevenue / 1000).toLocaleString('id-ID')}k
        </span>
      </div>

      <div className="stat-3d-viewport">
        <Canvas
          camera={{ position: [0, 2.2, 3.2], fov: 42 }}
          shadows
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={1.1} />
          <directionalLight position={[4, 7, 3]} intensity={1.6} castShadow />
          <pointLight position={[-3, 2, -2]} intensity={0.5} color="#C5A66B" />

          <LuxuryFinancialPillars
            pillars={stats.hourlyPillars}
            onHoverPillar={setHoveredPillar}
          />

          <OrbitControls
            enableZoom={false}
            enablePan={false}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 2.2}
          />
        </Canvas>

        {hoveredPillar ? (
          <div className="stat-tooltip-overlay font-ui">
            <strong>Pukul {hoveredPillar.time} WIB</strong>
            <span>Rp {hoveredPillar.amount.toLocaleString('id-ID')} • {hoveredPillar.txCount} Transaksi</span>
          </div>
        ) : (
          <div className="stat-drag-hint font-ui">
            Drag untuk memutar • Hover pilar finansial
          </div>
        )}
      </div>

      <div className="stat-card-footer">
        <span className="stat-status-indicator font-ui">
          <span className="status-dot-green"></span> {stats.statusNote}
        </span>
        <span className="stat-detail-link font-ui">Rincian →</span>
      </div>
    </div>
  );
}
