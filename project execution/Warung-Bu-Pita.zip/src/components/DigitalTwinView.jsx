import React, { useState } from 'react';
import {
  GitCompare,
  Calendar,
  Save,
  CheckCircle,
  AlertTriangle,
  HelpCircle,
  RefreshCw,
  Sparkles,
  ClipboardList,
  Layers,
  ArrowRight,
  ShieldCheck,
  Check,
  Percent,
  SlidersHorizontal,
} from 'lucide-react';
import { calculateBatchReconciliation } from '../utils/digitalTwinLogic';

export default function DigitalTwinView({
  products,
  lastReconciliation,
  onSaveReconciliation,
  onNavigateToDashboard,
}) {
  // State input stok fisik per produk (Langkah 3: Operator mengisi stok fisik setiap item)
  const [physicalInputs, setPhysicalInputs] = useState(() => {
    // Inisialisasi awal dengan nilai demo atau nilai rekonsiliasi tersimpan
    const initial = {};
    products.forEach((p) => {
      const prev = lastReconciliation?.items?.find((item) => item.id === p.id);
      if (prev && prev.physicalStock !== undefined) {
        initial[p.id] = prev.physicalStock;
      } else {
        initial[p.id] = p.defaultDemoPhysical !== undefined ? p.defaultDemoPhysical : p.digitalStock;
      }
    });
    return initial;
  });

  // State untuk melacak apakah tombol Simpan sudah ditekan pada sesi ini
  const [isCalculated, setIsCalculated] = useState(() => !!lastReconciliation);
  const [activeStep, setActiveStep] = useState(() => (lastReconciliation ? 12 : 3));

  // Handler update input stok fisik
  const handleInputChange = (productId, val) => {
    // Hanya izinkan angka non-negatif
    const cleaned = val === '' ? '' : Math.max(0, parseInt(val, 10) || 0);
    setPhysicalInputs((prev) => ({
      ...prev,
      [productId]: cleaned,
    }));
  };

  // Helper untuk mengisi preset demo dengan variasi
  const handleLoadDemoValues = () => {
    const demoData = {};
    products.forEach((p) => {
      demoData[p.id] = p.defaultDemoPhysical !== undefined ? p.defaultDemoPhysical : p.digitalStock;
    });
    setPhysicalInputs(demoData);
  };

  // Handler tombol Simpan (Langkah 4 -> Menjalankan Langkah 5, 6, 7, 8, 9, 10, 11, 12)
  const handleSave = (e) => {
    e.preventDefault();

    // Jalankan kalkulasi bisnis murni rekonsiliasi stok
    // Langkah 5: Sistem menghitung selisih antara stok fisik dan stok digital (|fisik - digital|)
    // Langkah 6: Sistem memeriksa apakah selisih stok maksimal 5%
    // Langkah 7: Jika selisih <= 5%, sistem menandai status Sesuai
    // Langkah 8: Jika selisih > 5%, sistem menandai status Tidak Sesuai
    // Langkah 9: Sistem menghitung persentase kesesuaian stok
    const result = calculateBatchReconciliation(products, physicalInputs);

    // Langkah 10: Sistem menampilkan hasil kesesuaian pada dashboard (dikirim ke parent state)
    onSaveReconciliation(result);

    setIsCalculated(true);
    setActiveStep(12); // Langkah 12: Proses selesai
  };

  // Hitung total stok digital terdaftar
  const totalDigitalStock = products.reduce((sum, p) => sum + p.digitalStock, 0);

  // Dapatkan data item hasil kalkulasi jika sudah disimpan
  const reconciledItems = isCalculated && lastReconciliation ? lastReconciliation.items : null;

  // Daftar item tidak sesuai untuk Langkah 11 (Operator memeriksa item yang berstatus Tidak Sesuai)
  const itemsTidakSesuai = isCalculated && lastReconciliation
    ? lastReconciliation.itemsTidakSesuai
    : [];

  return (
    <div className="digital-twin-content">
      {/* 1. Header dengan judul "Digital Twin Stock Monitoring" dan penjelasan singkat */}
      <section className="dt-header-card">
        <div className="dt-header-left">
          <div className="dt-badge-pill">
            <Sparkles size={14} /> Modul Rekonsiliasi Digital Twin • Standar Operasional
          </div>
          <h2 className="dt-title font-serif">Digital Twin Stock Monitoring</h2>
          <p className="dt-description">
            Sistem mencocokkan data stok digital tersimpan dengan hasil perhitungan stok fisik etalase secara nyata.
            Toleransi selisih yang diperbolehkan adalah <strong>maksimal 5%</strong> untuk status <strong>Sesuai</strong>.
          </p>
        </div>
        <div className="dt-header-right">
          <button
            type="button"
            className="btn-demo-preset"
            onClick={handleLoadDemoValues}
            title="Muat data hitungan fisik demo realistis"
          >
            <RefreshCw size={14} />
            <span>Muat Contoh Data Demo</span>
          </button>
        </div>
      </section>

      {/* 2. Ringkasan stok digital dan tanggal pemeriksaan terakhir */}
      <section className="dt-summary-grid">
        <div className="dt-metric-card">
          <div className="metric-icon-box bg-olive-soft">
            <Layers size={20} className="text-olive" />
          </div>
          <div className="metric-details">
            <span className="metric-label">Total Stok Digital</span>
            <div className="metric-number-row">
              <span className="metric-num">{totalDigitalStock}</span>
              <span className="metric-sub">pcs ({products.length} Item)</span>
            </div>
            <span className="metric-note">Tercatat di basis data inventaris</span>
          </div>
        </div>

        <div className="dt-metric-card">
          <div className="metric-icon-box bg-peach-soft">
            <Calendar size={20} className="text-terracotta" />
          </div>
          <div className="metric-details">
            <span className="metric-label">Tanggal Pemeriksaan Terakhir</span>
            <div className="metric-number-row">
              <span className="metric-date-text">
                {lastReconciliation?.timestamp ? (
                  new Date(lastReconciliation.timestamp).toLocaleString('id-ID', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  }) + ' WIB'
                ) : (
                  <span className="text-muted">Belum diperiksa hari ini</span>
                )}
              </span>
            </div>
            <span className="metric-note">
              {lastReconciliation ? 'Tersimpan ke Dashboard' : 'Tekan Simpan untuk merekam'}
            </span>
          </div>
        </div>

        {/* 6. Ringkasan persentase kesesuaian stok (Step 9 & 10) */}
        <div className={`dt-metric-card ${isCalculated ? 'metric-card-active' : ''}`}>
          <div className="metric-icon-box bg-olive-strong">
            <Percent size={20} className="text-white" />
          </div>
          <div className="metric-details">
            <span className="metric-label">Persentase Kesesuaian Stok</span>
            <div className="metric-number-row">
              <span className="metric-num text-olive">
                {isCalculated && lastReconciliation
                  ? `${lastReconciliation.persentaseKesesuaian}%`
                  : '-- %'}
              </span>
              {isCalculated && lastReconciliation && (
                <span
                  className={`metric-status-tag ${
                    lastReconciliation.persentaseKesesuaian >= 80 ? 'tag-sesuai' : 'tag-tidak-sesuai'
                  }`}
                >
                  {lastReconciliation.totalSesuai} Sesuai / {lastReconciliation.totalItems} Item
                </span>
              )}
            </div>
            <span className="metric-note">
              {isCalculated ? 'Hasil perhitungan rekonsiliasi aktif' : 'Menunggu operator menekan Simpan'}
            </span>
          </div>
        </div>
      </section>

      {/* Progress Indicator (12 Tahapan Rekonsiliasi) */}
      <div className="reconciliation-status-ribbon">
        <span className="ribbon-title">
          <ClipboardList size={15} /> Alur Rekonsiliasi:
        </span>
        <div className="ribbon-steps">
          <span className="ribbon-step done">1. Menu Dipilih ✓</span>
          <span className="ribbon-step done">2. Stok Digital Ditampilkan ✓</span>
          <span className={`ribbon-step ${activeStep >= 3 ? 'active' : ''}`}>
            3. Isi Stok Fisik
          </span>
          <span className={`ribbon-step ${isCalculated ? 'done' : ''}`}>
            4-9. Simpan & Hitung Selisih
          </span>
          <span className={`ribbon-step ${isCalculated ? 'done' : ''}`}>
            10. Hasil di Dashboard
          </span>
          <span className={`ribbon-step ${isCalculated ? 'active' : ''}`}>
            11. Periksa Tidak Sesuai
          </span>
          <span className={`ribbon-step ${isCalculated ? 'finish' : ''}`}>
            12. Proses Selesai {isCalculated ? '✓' : ''}
          </span>
        </div>
      </div>

      {/* FORM UTAMA REKONSILIASI STOK */}
      <form onSubmit={handleSave} className="reconciliation-form">
        {/* 3. Tabel daftar stok digital & 4. Input stok fisik */}
        <div className="table-card-container">
          <div className="table-header-bar">
            <div>
              <h3 className="table-title font-serif">Tabel Rekonsiliasi Stok Digital vs Fisik</h3>
              <p className="table-subtitle">
                Isi jumlah fisik riil di etalase/dapur, lalu klik tombol Simpan untuk memproses rekonsiliasi.
              </p>
            </div>
            <div className="table-legend">
              <span className="legend-item">
                <span className="dot dot-success"></span> ≤ 5% : Sesuai
              </span>
              <span className="legend-item">
                <span className="dot dot-warning"></span> &gt; 5% : Tidak Sesuai
              </span>
            </div>
          </div>

          <div className="table-scroll-wrapper">
            <table className="reconciliation-table">
              <thead>
                <tr>
                  <th style={{ width: '60px' }}>No</th>
                  <th>Produk & SKU</th>
                  <th style={{ width: '130px' }} className="text-center">
                    Stok Digital
                  </th>
                  <th style={{ width: '200px' }} className="text-center">
                    Input Stok Fisik
                  </th>
                  <th style={{ width: '110px' }} className="text-center">
                    Selisih
                  </th>
                  <th style={{ width: '130px' }} className="text-center">
                    % Selisih
                  </th>
                  <th style={{ width: '140px' }} className="text-center">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {products.map((product, idx) => {
                  const currentValue = physicalInputs[product.id] ?? '';
                  const reconciledItem = reconciledItems?.find((i) => i.id === product.id);

                  return (
                    <tr
                      key={product.id}
                      className={
                        reconciledItem
                          ? reconciledItem.status === 'Tidak Sesuai'
                            ? 'row-mismatch'
                            : 'row-match'
                          : ''
                      }
                    >
                      <td className="text-muted text-center font-mono">{idx + 1}</td>
                      <td>
                        <div className="product-cell-name">
                          <span className="product-row-emoji">{product.imageEmoji}</span>
                          <div>
                            <span className="product-table-title">{product.name}</span>
                            <div className="product-table-meta">
                              <span className="sku-tag">{product.sku}</span>
                              <span className="cat-tag">{product.category}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Stok Digital */}
                      <td className="text-center font-bold">
                        <span className="digital-stock-badge">
                          {product.digitalStock} <span className="unit-label">{product.unit}</span>
                        </span>
                      </td>

                      {/* 4. Input Stok Fisik untuk setiap item yang dapat diisi operator */}
                      <td className="text-center">
                        <div className="input-qty-container">
                          <input
                            type="number"
                            min="0"
                            step="1"
                            value={currentValue}
                            onChange={(e) => handleInputChange(product.id, e.target.value)}
                            placeholder="0"
                            className="input-physical-stock"
                            required
                            aria-label={`Input stok fisik untuk ${product.name}`}
                          />
                          <span className="input-unit-label">{product.unit}</span>
                        </div>
                      </td>

                      {/* Selisih: |Fisik - Digital| (Langkah 5) */}
                      <td className="text-center font-mono">
                        {reconciledItem ? (
                          <span className="diff-badge">
                            {reconciledItem.selisih} {product.unit}
                          </span>
                        ) : (
                          <span className="text-muted font-italic">-</span>
                        )}
                      </td>

                      {/* Persentase Selisih (Langkah 6) */}
                      <td className="text-center font-mono">
                        {reconciledItem ? (
                          <span
                            className={`pct-badge ${
                              reconciledItem.persentaseSelisih <= 5 ? 'pct-good' : 'pct-bad'
                            }`}
                          >
                            {reconciledItem.persentaseSelisih}%
                          </span>
                        ) : (
                          <span className="text-muted font-italic">-</span>
                        )}
                      </td>

                      {/* Status (Langkah 7 & 8) */}
                      <td className="text-center">
                        {reconciledItem ? (
                          <span
                            className={`status-pill ${
                              reconciledItem.status === 'Sesuai' ? 'pill-sesuai' : 'pill-tidak-sesuai'
                            }`}
                          >
                            {reconciledItem.status === 'Sesuai' ? (
                              <>
                                <Check size={14} /> Sesuai
                              </>
                            ) : (
                              <>
                                <AlertTriangle size={14} /> Tidak Sesuai
                              </>
                            )}
                          </span>
                        ) : (
                          <span className="status-pill pill-pending">Belum Dihitung</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* 5. Tombol Simpan untuk memulai proses perhitungan */}
          <div className="table-action-footer">
            <div className="footer-notes">
              <span className="formula-hint">
                💡 <strong>Rumus Rekonsiliasi:</strong> Selisih = |Stok Fisik - Stok Digital| • % Selisih = (Selisih / Stok Digital) × 100% • Status Sesuai jika ≤ 5%.
              </span>
            </div>
            <div className="footer-button-group">
              <button
                type="submit"
                className="btn-save-reconciliation"
                title="Tekan Simpan untuk menjalankan perhitungan rekonsiliasi otomatis"
              >
                <Save size={18} />
                <span>Simpan & Proses Rekonsiliasi</span>
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* 7. Daftar item dengan status Tidak Sesuai (Langkah 11: Operator memeriksa item Tidak Sesuai) */}
      {isCalculated && (
        <section className="dt-review-section">
          <div className="review-card">
            <div className="review-header">
              <div className="review-title-group">
                <span className="review-badge-icon bg-terracotta">
                  <AlertTriangle size={18} className="text-white" />
                </span>
                <div>
                  <h3 className="review-title font-serif">
                    Pemeriksaan Item Tidak Sesuai (Tahap Verifikasi)
                  </h3>
                  <p className="review-desc">
                    Berikut daftar item dengan selisih stok <strong>melebihi toleransi 5%</strong> yang memerlukan verifikasi manual oleh operator.
                  </p>
                </div>
              </div>
              <span className="mismatch-counter">
                {itemsTidakSesuai.length} dari {products.length} Item Memiliki Deviasi
              </span>
            </div>

            {itemsTidakSesuai.length > 0 ? (
              <div className="mismatch-cards-grid">
                {itemsTidakSesuai.map((item) => (
                  <div key={item.id} className="mismatch-item-card">
                    <div className="mismatch-card-header">
                      <div className="mismatch-prod-info">
                        <span className="mismatch-emoji">{item.imageEmoji}</span>
                        <div>
                          <h4 className="mismatch-name">{item.name}</h4>
                          <span className="mismatch-sku">{item.sku} • {item.category}</span>
                        </div>
                      </div>
                      <span className="tag-tidak-sesuai-strong">Tidak Sesuai</span>
                    </div>

                    <div className="mismatch-stats-box">
                      <div className="box-col">
                        <span className="box-lbl">Stok Digital</span>
                        <span className="box-val text-olive">{item.digitalStock} {item.unit}</span>
                      </div>
                      <div className="box-divider">vs</div>
                      <div className="box-col">
                        <span className="box-lbl">Stok Fisik</span>
                        <span className="box-val text-terracotta">{item.physicalStock} {item.unit}</span>
                      </div>
                      <div className="box-divider">=</div>
                      <div className="box-col">
                        <span className="box-lbl">Selisih Deviasi</span>
                        <span className="box-val font-bold">
                          {item.selisih} {item.unit} ({item.persentaseSelisih}%)
                        </span>
                      </div>
                    </div>

                    <div className="mismatch-inspection-note">
                      <span className="inspection-badge">Tindakan Pemeriksaan Operator:</span>
                      <p className="inspection-text">
                        Deviasi sebesar {item.persentaseSelisih}% melampaui batas 5%. Periksa catatan penjualan kasir,
                        kemungkinan sisa gorengan di etalase, atau potensi kerusakan selama display etalase.
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-mismatch-box">
                <div className="check-circle-wrapper">
                  <CheckCircle size={32} className="text-olive" />
                </div>
                <h4 className="empty-title font-serif">Seluruh Item Berstatus Sesuai!</h4>
                <p className="empty-desc">
                  Tidak ada satupun item yang selisihnya melebihi batas 5%. Seluruh stok fisik dan stok digital
                  berada dalam tingkat akurasi prima.
                </p>
              </div>
            )}
          </div>
        </section>
      )}

      {/* 12. Langkah 12: Proses Selesai & Sinkronisasi Dashboard */}
      {isCalculated && (
        <section className="completion-card">
          <div className="completion-content">
            <div className="completion-icon">
              <ShieldCheck size={26} className="text-olive" />
            </div>
            <div className="completion-text">
              <h4 className="completion-heading font-serif">
                Langkah 12: Proses Rekonsiliasi Selesai
              </h4>
              <p className="completion-desc">
                Perhitungan selisih, pengecekan batas 5%, penentuan status Sesuai / Tidak Sesuai, dan kalkulasi
                persentase kesesuaian ({lastReconciliation?.persentaseKesesuaian}%) telah selesai dieksekusi dan
                diperbarui pada tampilan Dashboard.
              </p>
            </div>
          </div>
          <div className="completion-actions">
            <button
              type="button"
              className="btn-view-dashboard"
              onClick={onNavigateToDashboard}
            >
              <span>Lihat Hasil di Dashboard</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </section>
      )}
    </div>
  );
}

