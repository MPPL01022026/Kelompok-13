import React from 'react';
import { X, Sparkles } from 'lucide-react';

export default function StatDetailModal({ statData, onClose }) {
  if (!statData) return null;

  return (
    <div className="modal-backdrop-luxury" onClick={onClose} role="dialog" aria-modal="true">
      <div
        className="modal-luxury-window"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-top-bar">
          <div>
            <span className="editorial-pill font-ui">
              <Sparkles size={11} className="gold-icon" /> Rincian Metrik Bisnis
            </span>
            <h3 className="modal-headline font-editorial">{statData.title}</h3>
            <p className="modal-subhead font-ui">{statData.subtitle}</p>
          </div>
          <button
            type="button"
            className="btn-modal-dismiss"
            onClick={onClose}
            aria-label="Tutup jendela rincian"
          >
            <X size={18} />
          </button>
        </div>

        <div className="modal-content-area font-ui">
          {/* Detail untuk PRODUKSI */}
          {statData.id === 'production' && (
            <div className="modal-metric-breakdown">
              <div className="modal-summary-trio">
                <div className="trio-box">
                  <span className="trio-lbl">Total Produksi</span>
                  <span className="trio-val text-forest">{statData.total} pcs</span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Target Harian</span>
                  <span className="trio-val">{statData.target} pcs</span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Pencapaian</span>
                  <span className="trio-val text-gold">{statData.achievementPct}%</span>
                </div>
              </div>

              <h4 className="modal-sub-heading font-editorial">Rincian Batch Penggorengan</h4>
              <div className="modal-lines-list">
                {statData.batches.map((b) => (
                  <div key={b.id} className="modal-row-strip">
                    <div className="row-info-left">
                      <span className="row-dot" style={{ backgroundColor: b.color }}></span>
                      <div>
                        <strong className="row-title">{b.label}</strong>
                        <span className="row-meta">Pukul {b.time} • Menu: {b.item}</span>
                      </div>
                    </div>
                    <span className="row-val-bold">{b.value} pcs</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Detail untuk STOK PRODUK */}
          {statData.id === 'stock' && (
            <div className="modal-metric-breakdown">
              <div className="modal-summary-trio">
                <div className="trio-box">
                  <span className="trio-lbl">Total Stok Etalase</span>
                  <span className="trio-val text-forest">{statData.total} pcs</span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Tingkat Kesegaran</span>
                  <span className="trio-val text-gold">{statData.freshnessPct}%</span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Total Menu</span>
                  <span className="trio-val">{statData.products.length} Varian</span>
                </div>
              </div>

              <h4 className="modal-sub-heading font-editorial">Alokasi Stok Etalase 5 Produk</h4>
              <div className="modal-lines-list">
                {statData.products.map((p) => (
                  <div key={p.id} className="modal-row-strip">
                    <div className="row-info-left">
                      <span className="row-dot" style={{ backgroundColor: p.color }}></span>
                      <div>
                        <strong className="row-title">{p.name}</strong>
                        <span className="row-meta">{p.category}</span>
                      </div>
                    </div>
                    <span className="row-val-bold">{p.qty} {p.unit}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Detail untuk PENJUALAN */}
          {statData.id === 'sales' && (
            <div className="modal-metric-breakdown">
              <div className="modal-summary-trio">
                <div className="trio-box">
                  <span className="trio-lbl">Omzet Tercatat</span>
                  <span className="trio-val text-forest">
                    Rp {statData.revenue.toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Rerata Nilai Nota</span>
                  <span className="trio-val">
                    Rp {statData.avgTicket.toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Transaksi</span>
                  <span className="trio-val text-gold">{statData.transactions} Struk</span>
                </div>
              </div>

              <h4 className="modal-sub-heading font-editorial">Pilar Omzet per Interval Jam</h4>
              <div className="modal-lines-list">
                {statData.hourlyPillars.map((h) => (
                  <div key={h.time} className="modal-row-strip">
                    <div className="row-info-left">
                      <span className="row-dot" style={{ backgroundColor: h.color }}></span>
                      <div>
                        <strong className="row-title">Sesi {h.time} WIB</strong>
                        <span className="row-meta">{h.txCount} Transaksi Pembeli</span>
                      </div>
                    </div>
                    <span className="row-val-bold">
                      Rp {h.amount.toLocaleString('id-ID')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Detail untuk BAHAN BAKU */}
          {statData.id === 'rawMaterials' && (
            <div className="modal-metric-breakdown">
              <div className="modal-summary-trio">
                <div className="trio-box">
                  <span className="trio-lbl">Ketersediaan Rata-rata</span>
                  <span className="trio-val text-forest">{statData.availabilityPct}%</span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Status Ketahanan</span>
                  <span className="trio-val text-gold">{statData.statusLevel}</span>
                </div>
                <div className="trio-box">
                  <span className="trio-lbl">Total Komoditas</span>
                  <span className="trio-val">{statData.segments.length} Item</span>
                </div>
              </div>

              <h4 className="modal-sub-heading font-editorial">Segmen Inventori Bahan Baku Gudang</h4>
              <div className="modal-lines-list">
                {statData.segments.map((s) => (
                  <div key={s.name} className="modal-row-strip">
                    <div className="row-info-left">
                      <span className="row-dot" style={{ backgroundColor: s.color }}></span>
                      <div>
                        <strong className="row-title">{s.name}</strong>
                        <span className="row-meta">Stok: {s.stock} (Kapasitas: {s.max})</span>
                      </div>
                    </div>
                    <span className="status-badge-optimum">{s.pct}% • {s.status}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="modal-bottom-actions">
          <button type="button" className="btn-modal-close-gold font-ui" onClick={onClose}>
            Tutup Rincian
          </button>
        </div>
      </div>
    </div>
  );
}
