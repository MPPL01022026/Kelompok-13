import React from 'react';
import { Package, ShieldCheck, Sparkles } from 'lucide-react';
import { DASHBOARD_STATS } from '../data/dashboardData';

export default function RawMaterialsSummary() {
  const materials = DASHBOARD_STATS.rawMaterials.segments;

  return (
    <div className="luxury-materials-card">
      <div className="materials-card-header">
        <div>
          <span className="editorial-pill font-ui">
            <Package size={12} className="gold-icon" /> Stok Gudang & Dapur
          </span>
          <h3 className="materials-title font-editorial">Ringkasan Inventori Bahan Baku</h3>
          <p className="materials-subtitle font-ui">
            Ketersediaan komoditas utama untuk menjaga kesinambungan mutu artisan Bu Pita.
          </p>
        </div>
        <div className="materials-status-tag font-ui">
          <ShieldCheck size={15} /> Status: <strong>Sangat Aman (3 Hari)</strong>
        </div>
      </div>

      <div className="materials-items-stack">
        {materials.map((item) => (
          <div key={item.name} className="material-line-item">
            <div className="material-meta-row font-ui">
              <div className="material-title-block">
                <span className="material-color-pip" style={{ backgroundColor: item.color }}></span>
                <span className="material-item-name">{item.name}</span>
              </div>
              <div className="material-stats-block">
                <strong className="material-cur-qty">{item.stock}</strong>
                <span className="material-max-cap">/ kap. {item.max}</span>
                <span className="material-opt-badge">{item.status} ({item.pct}%)</span>
              </div>
            </div>

            <div className="material-meter-track">
              <div
                className="material-meter-fill"
                style={{
                  width: `${item.pct}%`,
                  backgroundColor: item.color,
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      <div className="materials-card-note font-ui">
        <Sparkles size={13} className="gold-icon" />
        <span>Pemasok tepung terigu artisan dan minyak kelapa murni dijadwalkan kirim ulang pada hari Rabu pukul 10:00 WIB.</span>
      </div>
    </div>
  );
}
