/**
 * Logika Rekonsiliasi Digital Twin - Warung Bu Pita
 * Memisahkan logika perhitungan bisnis dari komponen UI.
 * Sesuai dengan aturan bisnis rekonsiliasi stok digital vs fisik Warung Bu Pita.
 */

/**
 * Menghitung selisih, persentase selisih, dan status kesesuaian untuk 1 item produk
 * @param {number} digitalStock - Jumlah stok digital tercatat di sistem
 * @param {number} physicalStock - Jumlah stok fisik hasil perhitungan operator
 * @returns {Object} { selisih, persentaseSelisih, status, isZeroSafe }
 */
export function calculateItemReconciliation(digitalStock, physicalStock) {
  const dStock = Number(digitalStock) || 0;
  const pStock = Number(physicalStock) || 0;

  // Rumus: Selisih = |stok fisik - stok digital|
  const selisih = Math.abs(pStock - dStock);

  // Penanganan kondisi stok digital nol secara aman
  if (dStock === 0) {
    if (pStock === 0) {
      // Jika stok digital dan stok fisik sama-sama nol -> Sesuai
      return {
        selisih: 0,
        persentaseSelisih: 0,
        status: 'Sesuai',
        isZeroSafe: true,
      };
    } else {
      // Jika stok digital nol tetapi stok fisik lebih dari nol -> Tidak Sesuai
      return {
        selisih,
        persentaseSelisih: 100, // Penanda selisih penuh
        status: 'Tidak Sesuai',
        isZeroSafe: true,
      };
    }
  }

  // Rumus: Persentase selisih = (selisih / stok digital) * 100%
  const persentaseSelisih = (selisih / dStock) * 100;

  // Aturan Ambang Batas 5%:
  // Jika persentase selisih <= 5% -> Sesuai
  // Jika persentase selisih > 5% -> Tidak Sesuai
  const status = persentaseSelisih <= 5 ? 'Sesuai' : 'Tidak Sesuai';

  return {
    selisih,
    persentaseSelisih: Number(persentaseSelisih.toFixed(2)),
    status,
    isZeroSafe: false,
  };
}

/**
 * Menghitung rekonsiliasi batch untuk seluruh item produk
 * @param {Array} products - Daftar produk dengan stok digital
 * @param {Object} physicalStockMap - Peta id/kode produk ke input stok fisik operator
 * @returns {Object} Hasil rekonsiliasi batch dan ringkasan kesesuaian
 */
export function calculateBatchReconciliation(products, physicalStockMap) {
  if (!products || products.length === 0) {
    return {
      items: [],
      totalItems: 0,
      totalSesuai: 0,
      totalTidakSesuai: 0,
      persentaseKesesuaian: 0,
      itemsTidakSesuai: [],
      timestamp: new Date().toISOString(),
    };
  }

  const items = products.map((product) => {
    const rawPhysicalInput = physicalStockMap[product.id];
    // Pastikan angka valid (default ke 0 jika kosong atau belum diisi)
    const physicalStock = rawPhysicalInput !== undefined && rawPhysicalInput !== ''
      ? Math.max(0, parseInt(rawPhysicalInput, 10) || 0)
      : 0;

    const result = calculateItemReconciliation(product.digitalStock, physicalStock);

    return {
      ...product,
      physicalStock,
      selisih: result.selisih,
      persentaseSelisih: result.persentaseSelisih,
      status: result.status,
    };
  });

  const totalItems = items.length;
  const totalSesuai = items.filter((item) => item.status === 'Sesuai').length;
  const totalTidakSesuai = items.filter((item) => item.status === 'Tidak Sesuai').length;

  // Rumus: Persentase kesesuaian stok = (jumlah item berstatus Sesuai / jumlah seluruh item) * 100%
  const persentaseKesesuaian = totalItems > 0
    ? Number(((totalSesuai / totalItems) * 100).toFixed(1))
    : 0;

  const itemsTidakSesuai = items.filter((item) => item.status === 'Tidak Sesuai');

  return {
    items,
    totalItems,
    totalSesuai,
    totalTidakSesuai,
    persentaseKesesuaian,
    itemsTidakSesuai,
    timestamp: new Date().toISOString(),
  };
}

