import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import DigitalTwinView from './components/DigitalTwinView';
import { INITIAL_PRODUCTS, DEMO_METADATA } from './data/initialProducts';
import { calculateBatchReconciliation } from './utils/digitalTwinLogic';
import { Menu, Sparkles } from 'lucide-react';
import './App.css';

function App() {
  const [products] = useState(INITIAL_PRODUCTS);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // State hasil rekonsiliasi stok Digital Twin
  const [reconciliationResult, setReconciliationResult] = useState(() => {
    const demoPhysicalMap = {};
    INITIAL_PRODUCTS.forEach((p) => {
      demoPhysicalMap[p.id] = p.defaultDemoPhysical;
    });
    return calculateBatchReconciliation(INITIAL_PRODUCTS, demoPhysicalMap);
  });

  const handleSaveReconciliation = (newResult) => {
    setReconciliationResult(newResult);
  };

  return (
    <div className="luxury-app-frame">
      {/* 1. Sidebar Deep Forest Green */}
      <Sidebar
        activeTab={activeTab}
        onSelectMenu={(menuId) => setActiveTab(menuId)}
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
      />

      {/* Main Content Stage */}
      <div className="luxury-main-stage">
        {/* Mobile Top Header */}
        <div className="mobile-luxury-bar">
          <button
            type="button"
            className="btn-mobile-nav"
            onClick={() => setIsMobileMenuOpen(true)}
            aria-label="Buka menu navigasi"
          >
            <Menu size={22} />
          </button>
          <span className="mobile-brand-title font-editorial">Warung Bu Pita</span>
          <span className="mobile-luxury-tag font-ui">Artisan</span>
        </div>

        {/* Dynamic Page Content */}
        <main className="luxury-content-canvas">
          {activeTab === 'dashboard' ? (
            <DashboardView
              onNavigateToDigitalTwin={() => setActiveTab('digital-twin')}
            />
          ) : activeTab === 'digital-twin' ? (
            <DigitalTwinView
              products={products}
              lastReconciliation={reconciliationResult}
              onSaveReconciliation={handleSaveReconciliation}
              onNavigateToDashboard={() => setActiveTab('dashboard')}
            />
          ) : (
            /* Sub-Menu Placeholder (Produksi, Inventori, Penjualan, Laporan, Pengaturan) */
            <div className="luxury-subview-panel">
              <div className="subview-editorial-card">
                <span className="subview-crest font-editorial">P</span>
                <h3 className="subview-title font-editorial">
                  Modul {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Terhubung
                </h3>
                <p className="subview-narrative font-ui">
                  Sistem manajemen operasional terintegrasi langsung dengan basis data dapur utama Warung Bu Pita.
                </p>
                <div className="subview-cta-group font-ui">
                  <button
                    type="button"
                    className="btn-luxury-primary"
                    onClick={() => setActiveTab('dashboard')}
                  >
                    Kembali ke Dashboard Utama
                  </button>
                  <button
                    type="button"
                    className="btn-luxury-secondary"
                    onClick={() => setActiveTab('digital-twin')}
                  >
                    Buka Modul Digital Twin
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Editorial Footer */}
        <footer className="luxury-page-footer font-ui">
          <div className="footer-content-row">
            <span className="footer-brand font-editorial">Warung Bu Pita</span>
            <span className="footer-sub">
              Luxury Green × Modern Artisan Culinary • Alur Dua
            </span>
            <span className="footer-tag">Sistem Manajemen UMKM</span>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
