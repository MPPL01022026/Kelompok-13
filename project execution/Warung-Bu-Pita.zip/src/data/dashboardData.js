/**
 * Data Sumber Dashboard Warung Bu Pita
 * Konsep: LUXURY GREEN × MODERN ARTISAN CULINARY
 * Palet: Deep Forest Green (#193C2E), Olive Green (#315640), Sage Green (#9BAF9B),
 * Moss Green (#71836A), Soft Ivory (#F5F4EC), Warm Gold (#C5A66B)
 */

export const DASHBOARD_STATS = {
  // 1. Produksi Hari Ini
  production: {
    id: 'production',
    title: 'Produksi Hari Ini',
    subtitle: 'Kapasitas Dapur Utama',
    total: 520,
    target: 600,
    unit: 'pcs',
    achievementPct: 86.7,
    statusNote: 'Batch ke-4 sedang berlangsung',
    batches: [
      { id: 'b1', time: '08:00', label: 'Batch Pagi 1', value: 140, item: 'Risol Sayur & Lumpia', color: '#193C2E' },
      { id: 'b2', time: '10:30', label: 'Batch Pagi 2', value: 160, item: 'Bakso Goreng', color: '#315640' },
      { id: 'b3', time: '13:30', label: 'Batch Siang', value: 130, item: 'Tahu Isi & Risol', color: '#71836A' },
      { id: 'b4', time: '16:00', label: 'Batch Sore', value: 90, item: 'Pisang Coklat Premium', color: '#C5A66B' },
    ],
  },

  // 2. Total Stok Produk (5 Produk Wajib)
  stock: {
    id: 'stock',
    title: 'Total Stok Produk',
    subtitle: 'Akumulasi Etalase & Dapur',
    total: 555,
    unit: 'pcs',
    freshnessPct: 98,
    statusNote: 'Semua produk segar buatan hari ini',
    products: [
      { id: 'prod-001', name: 'Risol Sayur', qty: 120, unit: 'pcs', color: '#C5A66B', category: 'Gorengan Gurih', shape: 'cylinder' },
      { id: 'prod-002', name: 'Lumpia', qty: 95, unit: 'pcs', color: '#9BAF9B', category: 'Gorengan Gurih', shape: 'cylinder' },
      { id: 'prod-003', name: 'Bakso Goreng', qty: 150, unit: 'pcs', color: '#315640', category: 'Camilan Artisan', shape: 'sphere' },
      { id: 'prod-004', name: 'Tahu Isi', qty: 80, unit: 'pcs', color: '#71836A', category: 'Gorengan Gurih', shape: 'box' },
      { id: 'prod-005', name: 'Pisang Coklat', qty: 110, unit: 'pcs', color: '#193C2E', category: 'Jajanan Manis', shape: 'capsule' },
    ],
  },

  // 3. Penjualan Hari Ini
  sales: {
    id: 'sales',
    title: 'Penjualan Hari Ini',
    subtitle: 'Pendapatan Kasir & Pesanan',
    revenue: 2450000,
    targetRevenue: 2800000,
    transactions: 142,
    avgTicket: 17250,
    achievementPct: 87.5,
    statusNote: '+18% di atas rerata harian',
    hourlyPillars: [
      { time: '09:00', amount: 380000, txCount: 22, height: 1.1, color: '#9BAF9B' },
      { time: '11:00', amount: 620000, txCount: 36, height: 1.9, color: '#315640' },
      { time: '13:00', amount: 510000, txCount: 29, height: 1.5, color: '#71836A' },
      { time: '15:00', amount: 640000, txCount: 38, height: 2.1, color: '#193C2E' },
      { time: '17:00', amount: 300000, txCount: 17, height: 0.95, color: '#C5A66B' },
    ],
  },

  // 4. Ketersediaan Bahan Baku
  rawMaterials: {
    id: 'rawMaterials',
    title: 'Ketersediaan Bahan Baku',
    subtitle: 'Gudang & Dapur Olahan',
    availabilityPct: 92,
    statusLevel: 'Sangat Aman',
    statusNote: 'Ketahanan stok untuk 3 hari ke depan',
    segments: [
      { name: 'Tepung Terigu Artisan', stock: '48 kg', max: '50 kg', pct: 96, color: '#193C2E', status: 'Optimal' },
      { name: 'Minyak Kelapa Murni', stock: '65 liter', max: '70 liter', pct: 93, color: '#315640', status: 'Optimal' },
      { name: 'Pisang Raja Organik', stock: '22 sisir', max: '25 sisir', pct: 88, color: '#C5A66B', status: 'Optimal' },
      { name: 'Coklat Couverture Premium', stock: '14 kg', max: '15 kg', pct: 93, color: '#193C2E', status: 'Optimal' },
      { name: 'Daging Ayam & Udang Segar', stock: '18 kg', max: '20 kg', pct: 90, color: '#71836A', status: 'Optimal' },
      { name: 'Sayur Wortel & Rebung Segar', stock: '25 kg', max: '30 kg', pct: 83, color: '#9BAF9B', status: 'Cukup' },
    ],
  },
};

// Data Tren Produksi vs Penjualan
export const HOURLY_TRENDS = [
  { time: '08:00', produksi: 80, penjualan: 25 },
  { time: '10:00', produksi: 140, penjualan: 95 },
  { time: '12:00', produksi: 110, penjualan: 135 },
  { time: '14:00', produksi: 90, penjualan: 85 },
  { time: '16:00', produksi: 70, penjualan: 120 },
  { time: '18:00', produksi: 30, penjualan: 60 },
];

// Showcase 5 Produk Unggulan Bu Pita dengan visual 3D
export const SHOWCASE_PRODUCTS = [
  {
    id: 'prod-001',
    name: 'Risol Sayur',
    subtitle: 'Ragout Wortel & Rempah Jawa',
    price: 3500,
    stock: 120,
    soldToday: 135,
    tag: 'Signature Gurih',
    rating: 4.9,
    accentColor: '#C5A66B',
    shapeType: 'risol',
    description: 'Kulit keemasan lembut dengan isian wortel segar, kentang, dan rempah aromatik pilihan.',
  },
  {
    id: 'prod-002',
    name: 'Lumpia',
    subtitle: 'Rebung Manis Gurih Tradisional',
    price: 4000,
    stock: 95,
    soldToday: 110,
    tag: 'Artisan Heritage',
    rating: 4.8,
    accentColor: '#315640',
    shapeType: 'lumpia',
    description: 'Rebung pilihan dipadu cacahan ayam berbumbu bawang karamelisasi dengan saus tauco bawang putih.',
  },
  {
    id: 'prod-003',
    name: 'Bakso Goreng',
    subtitle: 'Ayam & Udang Mekar Krispi',
    price: 5000,
    stock: 150,
    soldToday: 180,
    tag: 'Best Seller',
    rating: 5.0,
    accentColor: '#193C2E',
    shapeType: 'bakso',
    description: 'Bakso goreng mekar bertekstur kopong kenyal dengan aroma gurih sari udang dan minyak wijen murni.',
  },
  {
    id: 'prod-004',
    name: 'Tahu Isi',
    subtitle: 'Tahu Pong Sayur Pedas Wangi',
    price: 3000,
    stock: 80,
    soldToday: 95,
    tag: 'Camilan Klasik',
    rating: 4.7,
    accentColor: '#71836A',
    shapeType: 'tahu',
    description: 'Tahu Sumedang berongga renyah diisi serutan wortel dan kol dengan sengatan lada putih harum.',
  },
  {
    id: 'prod-005',
    name: 'Pisang Coklat',
    subtitle: 'Pisang Raja Lumer Dark Couverture',
    price: 3500,
    stock: 110,
    soldToday: 145,
    tag: 'Favorit Manis',
    rating: 4.9,
    accentColor: '#C5A66B',
    shapeType: 'piscok',
    description: 'Pisang raja matang pohon berbalut lelehan dark chocolate murni dalam balutan kulit ekstra renyah.',
  },
];

// Aktivitas Operasional Terbaru
export const RECENT_OPERATIONAL_ACTIVITIES = [
  {
    id: 'act-1',
    time: '16:45 WIB',
    type: 'produksi',
    iconName: 'Flame',
    title: 'Batch #14 Pisang Coklat Selesai',
    description: '40 pcs pisang coklat lumer diangkat dengan suhu penggorengan stabil 170°C.',
    badge: 'Produksi',
  },
  {
    id: 'act-2',
    time: '15:20 WIB',
    type: 'penjualan',
    iconName: 'ShoppingBag',
    title: 'Pesanan 30 Paket Snack Box',
    description: 'Pengemasan higienis kotak besek bambu selesai dikirim via kurir mitra.',
    badge: 'Penjualan',
  },
  {
    id: 'act-3',
    time: '14:00 WIB',
    type: 'inventori',
    iconName: 'CheckCircle2',
    title: 'Restock Etalase Display Dapur',
    description: 'Penambahan 30 Bakso Goreng dan 25 Risol Sayur ke showcase penghangat.',
    badge: 'Etalase',
  },
  {
    id: 'act-4',
    time: '12:15 WIB',
    type: 'bahan-baku',
    iconName: 'Truck',
    title: 'Penerimaan Bahan Baku Organik',
    description: '25 sisir Pisang Raja dan 20 kg Daging Ayam cincang tiba dari mitra lokal.',
    badge: 'Logistik',
  },
  {
    id: 'act-5',
    time: '08:30 WIB',
    type: 'operasional',
    iconName: 'Sparkles',
    title: 'Pembukaan Dapur Utama',
    description: 'Pengecekan kualitas minyak kelapa dan persiapan adonan batch pertama oleh Bu Pita.',
    badge: 'Dapur',
  },
];
