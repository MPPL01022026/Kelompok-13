/**
 * Data Demo Produk UMKM Warung Bu Pita
 * Memuat 5 item produk wajib yang telah ditentukan.
 * Seluruh data diberi label jelas sebagai Data Demo.
 */

export const INITIAL_PRODUCTS = [
  {
    id: 'prod-001',
    sku: 'WBP-RS01',
    name: 'Risol Sayur',
    category: 'Gorengan Gurih',
    unit: 'pcs',
    price: 3500,
    digitalStock: 120,
    defaultDemoPhysical: 118, // Selisih 2 (1.67%) -> Sesuai (<= 5%)
    imageEmoji: '🥟',
    description: 'Risol renyah isi wortel, kentang, dan bumbu rempah pilihan khas Bu Pita.',
  },
  {
    id: 'prod-002',
    sku: 'WBP-LM02',
    name: 'Lumpia',
    category: 'Gorengan Gurih',
    unit: 'pcs',
    price: 4000,
    digitalStock: 95,
    defaultDemoPhysical: 93, // Selisih 2 (2.11%) -> Sesuai (<= 5%)
    imageEmoji: '🌯',
    description: 'Lumpia isi rebung manis gurih dengan saus tauco bawang asli.',
  },
  {
    id: 'prod-003',
    sku: 'WBP-BG03',
    name: 'Bakso Goreng',
    category: 'Camilan Artisan',
    unit: 'pcs',
    price: 5000,
    digitalStock: 150,
    defaultDemoPhysical: 162, // Selisih 12 (8.00%) -> Tidak Sesuai (> 5%)
    imageEmoji: '🧆',
    description: 'Bakso goreng mekar bertekstur kenyal garing dengan aroma ayam dan udang sedap.',
  },
  {
    id: 'prod-004',
    sku: 'WBP-TI04',
    name: 'Tahu Isi',
    category: 'Gorengan Gurih',
    unit: 'pcs',
    price: 3000,
    digitalStock: 80,
    defaultDemoPhysical: 80, // Selisih 0 (0.00%) -> Sesuai (<= 5%)
    imageEmoji: '🧈',
    description: 'Tahu pong coklat isi sayuran pedas gurih dibalut tepung krispi keemasan.',
  },
  {
    id: 'prod-005',
    sku: 'WBP-PC05',
    name: 'Pisang Coklat',
    category: 'Jajanan Manis',
    unit: 'pcs',
    price: 3500,
    digitalStock: 110,
    defaultDemoPhysical: 101, // Selisih 9 (8.18%) -> Tidak Sesuai (> 5%)
    imageEmoji: '🍌',
    description: 'Pisang raja manis lumer coklat premium berpadu kulit lumpia ekstra renyah.',
  },
];

export const DEMO_METADATA = {
  storeName: 'Warung Bu Pita',
  subtitle: 'Artisan Culinary & Traditional Snacks',
  dataTag: 'DATA DEMO UMKM - SIMULASI DIGITAL TWIN',
  lastAuditInitialDate: '31 Okt 2026, 08:30 WIB',
  location: 'Alur Dua',
  operatorName: 'Operator Pitstop 01',
};

